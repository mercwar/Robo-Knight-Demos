<?php
/*=====================================================================
    AIFVS-ARTIFACT: COPILOT_CMS_HANDLER_INTERFACE
    AVIS-ID: COPILOT_CMS.RUNTIME.HANDLER.INTERFACE
    AVIS-PATH: HTDOCS/PHP/COPILOT_CMS/HANDLER/COPILOT_CMS_HANDLER_INTERFACE.php
    AVIS-TYPE: HANDLER_INTERFACE
=====================================================================*/

interface COPILOT_CMS_HANDLER_INTERFACE
{
    public static function run(array $req): array;
}
?>
