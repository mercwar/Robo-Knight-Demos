﻿/* AVIS DO NOT REMOVE
::AVIS FILEINFO V01.00::
FILE.NAME      = rkfio.h;
FILE.TYPE      = HEADER;
FILE.VERSION   = V01.00;
FILE.MODULE    = AVIS.RKFIO;
FILE.PATH      = <PROJECT>/include/rkfio.h;
FILE.OWNER     = AI.FVS.AVIS.SYSTEM;
AVIS DO NOT REMOVE */

#ifndef AVIS_RKFIO_H
#define AVIS_RKFIO_H

#include <stdint.h>
#include "gf.h"



#endif
