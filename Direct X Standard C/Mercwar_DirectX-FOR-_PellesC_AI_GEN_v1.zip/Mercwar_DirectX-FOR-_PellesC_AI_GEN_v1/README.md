# Mercwar Robo-Knight Game (Pelles C Preview)
Fully populated KB-compatible demo with CyborgLang + AVIS.