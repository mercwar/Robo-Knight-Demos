﻿#include "dx11_pelles_safe.h"

/* Placeholders for textures or sprites later */
