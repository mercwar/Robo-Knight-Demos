﻿#ifndef GAME_LOGIC_H
#define GAME_LOGIC_H

void UpdateGame(void);
void RenderGame(void);

#endif
