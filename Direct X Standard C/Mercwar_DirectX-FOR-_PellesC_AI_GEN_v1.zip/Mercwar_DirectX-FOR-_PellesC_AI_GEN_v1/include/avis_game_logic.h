﻿/* AVIS FILE: avis_game_logic.h */

#ifndef AVIS_GAME_LOGIC_H
#define AVIS_GAME_LOGIC_H

/* AVIS: Game update */
void UpdateGame(void);

#endif /* AVIS_GAME_LOGIC_H */
