﻿#ifndef AVIS_LEGACY_H
#define AVIS_LEGACY_H

void AVIS_RegisterLegacy(const char *name, void *fn);

#endif
