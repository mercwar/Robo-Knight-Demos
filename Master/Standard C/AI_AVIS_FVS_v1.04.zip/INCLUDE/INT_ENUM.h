﻿#ifndef INT_ENUM_H
#define INT_ENUM_H

typedef enum _INT_ENUM
{
    INT_NONE = 0,

    INT_SEED_INFO = 1,
    INT_MASTER_INFO = 2,
    INT_MASTER_CONVERT_INFO = 3,
    INT_MASTER_COMBILE_INFO = 4

} INT_ENUM;

#endif
