﻿#ifndef MASTER_H
#define MASTER_H

typedef struct _MASTER_ {
    void *OBJ;   // optional global facility
} MASTER_;

#endif
