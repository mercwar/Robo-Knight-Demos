﻿#ifndef BEGIN_INI_H
#define BEGIN_INI_H

#ifdef __cplusplus
extern "C" {
#endif

void BEGIN_LoadADOFromINI(void);

#ifdef __cplusplus
}
#endif

#endif
