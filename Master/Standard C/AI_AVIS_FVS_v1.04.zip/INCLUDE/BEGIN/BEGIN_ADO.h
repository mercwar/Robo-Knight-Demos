﻿#ifndef BEGIN_ADO_H
#define BEGIN_ADO_H

#ifdef __cplusplus
extern "C" {
#endif

void BEGIN_ComputeADO(void);

#ifdef __cplusplus
}
#endif

#endif
