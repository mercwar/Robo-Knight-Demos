﻿// AVIS BATCH CBORD.SEED VERSION 1.00
// AVIS FILE: RETURN_EXE.C
// AVIS DEPENDS:
//   - RETURN.C (compiled separately)
//   - RETURN.H (included in WIN_MAIN.C)

// ------------------------------------------------------------
// EXECUTABLE RETURN VECTOR CALL
// ------------------------------------------------------------


AVIS_RETV = AVIS_RETURN(AVIS_RETA);

