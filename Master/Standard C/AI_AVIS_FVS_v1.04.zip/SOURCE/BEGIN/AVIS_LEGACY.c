﻿#include "AVIS_LEGACY.H"

void AVIS_RegisterLegacy(const char *name, void *fn)
{
    /* no-op stub */
}
