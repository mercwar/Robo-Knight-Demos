﻿// ------------------------------------------------------------
// AVIS BATCH CBORD.SEED VERSION 1.00
// AVIS FILE: SEED/SEED.C
// AVIS ROLE: SEED implementation (passive AVIS object)
// ------------------------------------------------------------

#include "BEGIN/SEED/SEED.H"

// SEED is a passive AVIS object.
// AVIS uses SEED. CYHY/MERCG use AVIS.
