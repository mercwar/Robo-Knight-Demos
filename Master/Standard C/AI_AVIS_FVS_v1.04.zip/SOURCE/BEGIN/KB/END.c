﻿// AVIS BATCH CBORD.SEED VERSION 1.00
// AVIS FILE: BEGIN/KB/END.c
// AVIS DEPENDS:
//   - BEGIN/BEGIN.H

// ------------------------------------------------------------
// KB END / SHUTDOWN LOGIC
// ------------------------------------------------------------

BEGIN.KB.LOG.PRINT("KB:END:ENTER");

// If you add KB subsystems later (REG_FIO, REG_LOGGER, etc.),
// their shutdown calls will go here.

BEGIN.KB.LOG.PRINT("KB:END:EXIT");
