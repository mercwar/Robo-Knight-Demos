﻿// AVIS BATCH CBORD.SEED VERSION 1.00
// AVIS FILE: BEGIN/KB/KB.c
// AVIS DEPENDS:
//   - BEGIN/BEGIN.H
//   - WIN_MAIN.H

// ------------------------------------------------------------
// KB ROOT INITIALIZATION
// ------------------------------------------------------------

BEGIN.KB.LOG.PRINT("KB:INIT");

// KB subsystem fields are already allocated in BEGIN object.
// This file is responsible ONLY for announcing readiness.

BEGIN.KB.LOG.PRINT("KB:READY");
