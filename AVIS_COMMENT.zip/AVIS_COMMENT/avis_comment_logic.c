﻿#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE

#include <windows.h>
#include <wchar.h>
#include <stdio.h>
#include <wctype.h>
/****************************************************************************
  AvisDetectInComments
   - Scans file at 'path'
   - Looks for the word "avis" (case-insensitive)
   - Only inside comments:
   - Returns 1 if found, 0 otherwise
 ****************************************************************************/
int AvisDetectInComments(const WCHAR *path)
{
    FILE *f = _wfopen(path, L"r, ccs=UTF-8");
    if (!f)
        return 0;

    int inBlock = 0;   
    int inLine  = 0;   

    WCHAR buffer[2048];

    while (fgetws(buffer, 2048, f))
    {
        WCHAR *p = buffer;

        while (*p)
        {
            /* Detect start of block comment */
            if (!inBlock && !inLine && p[0] == L'/' && p[1] == L'*')
            {
                inBlock = 1;
                p += 2;
                continue;
            }

            /* Detect end of block comment */
            if (inBlock && p[0] == L'*' && p[1] == L'/')
            {
                inBlock = 0;
                p += 2;
                continue;
            }

            /* Detect line comment */
            if (!inBlock && !inLine && p[0] == L'/' && p[1] == L'/')
            {
                inLine = 1;
                p += 2;
                continue;
            }

            /* If inside a comment, search for "avis" in the whole line */
            if (inBlock || inLine)
            {
                WCHAR lower[2048];
                int i = 0;

                while (buffer[i] && i < 2047)
                {
                    lower[i] = (WCHAR)towlower(buffer[i]);
                    i++;
                }
                lower[i] = 0;

                if (wcsstr(lower, L"avis"))
                {
                    fclose(f);
                    return 1; /* found */
                }

                break; /* done with this line */
            }

            p++;
        }

        inLine = 0; /* reset at end of line */
    }

    fclose(f);
    return 0; /* not found */
}
