﻿#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE

#include <windows.h>
#include <wchar.h>     /* fputws, fgetwc, fputwc, WEOF, wint_t */
#include <stdio.h>     /* FILE, _wfopen */
