﻿#ifndef AVIS_DROPIN_H
#define AVIS_DROPIN_H

#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE

#include <windows.h>
#include <wchar.h>

/* Drop-in: detect AVIS inside comments */
int AvisDetectInComments(const WCHAR *path);

/* Debug wrappers */
void AvisDebugMsg(const WCHAR *text);
void AvisImmediate(const WCHAR *text);

#endif
