/****************************************************************************
 * File    : AVIS_COMMENT.c
 * Purpose : Add-In main module (event router only)
 ****************************************************************************/

#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE

#include <windows.h>
#include <addin.h>

#include "avis_dropin.h"            // <-- REQUIRED
#include "avis_comment_template.h"  // optional

/* Globals */
static HINSTANCE g_hmod = NULL;
static HWND g_hwndMain = NULL;      // <-- REQUIRED

/* Globals */


/****************************************************************************
 * DllMain
 ****************************************************************************/
BOOL WINAPI DllMain(HINSTANCE hDLL, DWORD dwReason, LPVOID lpReserved)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
        g_hmod = hDLL;
        AvisDebugMsg(L"AVIS Add-In Loaded");
    }

    return TRUE;
}

/****************************************************************************
 * AddInMain
 ****************************************************************************/
ADDINAPI BOOL WINAPI AddInMain(HWND hwnd, ADDIN_EVENT eEvent)
{
    switch (eEvent)
    {
        case AIE_DOC_SAVE:
        {
            const WCHAR *path = L"H:\\htdocs\\robo-knight\\test.c";

            AvisImmediate(L"[AVIS] DETECTED inside comment");

            AvisDetectInComments(path);

            return TRUE;
        }
case AIE_APP_CREATE:
    g_hwndMain = hwnd;

    /* Get the Output window handle */
    HWND hwndOutput = FindWindowExW(hwnd, NULL, L"OutputWndClass", NULL);
    AvisSetOutputWindow(hwndOutput);

    AvisImmediate(L"[AVIS] Not found");

    return TRUE;

        default:
            return TRUE;
    }
}

/****************************************************************************
 * Optional exports
 ****************************************************************************/
ADDINAPI void WINAPI AddInCommand(HWND hwnd, LPCVOID pcvData)
{
    /* Not used */
}
ADDINAPI void WINAPI AddInSetup(HWND hwnd, LPCVOID pcvData)
{
    /* Not used */
}
