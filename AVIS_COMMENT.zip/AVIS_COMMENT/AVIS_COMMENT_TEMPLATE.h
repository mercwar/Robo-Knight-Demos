﻿// avis
/* this is an avis test */
#ifndef AVIS_COMMENT_TEMPLATE_H
#define AVIS_COMMENT_TEMPLATE_H

#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE

#include <windows.h>
#include <wchar.h>

/* Reserved for future AVIS templates */
static const WCHAR *AVIS_TEMPLATE =
    L"/* AVIS TEMPLATE PLACEHOLDER */\n";

#endif /* AVIS_COMMENT_TEMPLATE_H */
