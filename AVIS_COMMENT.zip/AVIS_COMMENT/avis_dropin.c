﻿#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE

#include <windows.h>
#include <wchar.h>
#include <stdio.h>
#include "avis_dropin.h"

/****************************************************************************
 * AvisDetectInComments
 *  - Scans file for "avis" inside comments
 *  - Prints result to Immediate Window
 ****************************************************************************/
int AvisDetectInComments(const WCHAR *path)
{
    FILE *f = _wfopen(path, L"r, ccs=UTF-8");
    if (!f)
    {
        AvisImmediate(L"[AVIS] FAILED TO OPEN FILE");
        return 0;
    }

    int inBlock = 0;
    int inLine  = 0;

    WCHAR buffer[2048];

    while (fgetws(buffer, 2048, f))
    {
        WCHAR *p = buffer;

        while (*p)
        {
            if (!inBlock && !inLine && p[0] == L'/' && p[1] == L'*')
            {
                inBlock = 1;
                p += 2;
                continue;
            }

            if (inBlock && p[0] == L'*' && p[1] == L'/')
            {
                inBlock = 0;
                p += 2;
                continue;
            }

            if (!inBlock && !inLine && p[0] == L'/' && p[1] == L'/')
            {
                inLine = 1;
                p += 2;
                continue;
            }

            if (inBlock || inLine)
            {
                WCHAR lower[2048];
                int i = 0;

                while (buffer[i] && i < 2047)
                {
                    lower[i] = (WCHAR)towlower(buffer[i]);
                    i++;
                }
                lower[i] = 0;

                if (wcsstr(lower, L"avis"))
                {
                    AvisImmediate(L"[AVIS] DETECTED inside comment");
                    fclose(f);
                    return 1;
                }

                break;
            }

            p++;
        }

        inLine = 0;
    }

    fclose(f);
    AvisImmediate(L"[AVIS] Not found");
    return 0;
}
