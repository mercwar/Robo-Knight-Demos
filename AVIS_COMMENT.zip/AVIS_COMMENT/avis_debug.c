﻿#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE

#include <windows.h>
#include <wchar.h>
#include "avis_dropin.h"

/* Pelles C Output Window handle */
static HWND hwndOutput = NULL;

/* Called by AddInMain to register the output window */
void AvisSetOutputWindow(HWND hwnd)
{
    hwndOutput = hwnd;
}

/* Print to Pelles C Output window */
void AvisImmediate(const WCHAR *text)
{
    if (hwndOutput)
    {
        SendMessageW(hwndOutput, WM_SETTEXT, 0, (LPARAM)text);
        SendMessageW(hwndOutput, WM_CHAR, '\n', 0);
    }
    else
    {
        MessageBoxW(NULL, L"[AVIS] Output window not set", L"DEBUG", MB_OK);
    }
}

/* Optional messagebox wrapper */
void AvisDebugMsg(const WCHAR *text)
{
    MessageBoxW(NULL, text, L"AVIS_DEBUG", MB_OK | MB_ICONINFORMATION);
}
